package model;

public class ConexionBaseDatos {
    private final int id;

    private boolean disponible;

    public ConexionBaseDatos(int id) {

        this.id = id;

        this.disponible = true;
    }

    public void abrir() {

        this.disponible = false;

        System.out.println("Conexion #" + id + " en uso");
    }

    public void cerrar() {

        this.disponible = true;

        System.out.println("Conexion #" + id + " liberada");
    }

    public boolean estaDisponible() {

        return this.disponible;
    }

    public int getId() {

        return this.id;
    }

    public void mostrarEstado() {

        String estado;

        if(disponible) {

            estado = "Disponible";
        }
        else {

            estado = "Ocupada";
        }

        System.out.printf("Conexion #%d -> %s\n", id, estado);
    }

}
