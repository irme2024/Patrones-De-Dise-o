package interfaces;

import model.ConexionBaseDatos;

public interface AdminConexion {
    ConexionBaseDatos obtenerConexion();

    void liberarConexion(ConexionBaseDatos conexion);

    void mostrarConexiones();
}
