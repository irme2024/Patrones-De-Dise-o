import admin.AdminConexiones;
import model.ConexionBaseDatos;

public class Main {
    public static void main(String[] args) {

        System.out.println("PATRON OBJECT POOL\n");

        AdminConexiones admin = AdminConexiones.getInstancia();

        System.out.println("===== PRIMERAS SOLICITUDES =====\n");

        ConexionBaseDatos c1 = admin.obtenerConexion();

        ConexionBaseDatos c2 = admin.obtenerConexion();

        ConexionBaseDatos c3 = admin.obtenerConexion();

        ConexionBaseDatos c4 = admin.obtenerConexion();

        admin.mostrarConexiones();

        System.out.println("\n===== LIBERANDO UNA CONEXION =====\n");

        admin.liberarConexion(c2);

        admin.mostrarConexiones();

        System.out.println("\n===== NUEVA SOLICITUD =====\n");

        ConexionBaseDatos c5 = admin.obtenerConexion();

        admin.mostrarConexiones();

        System.out.println("\n===== LIBERANDO TODAS =====\n");

        admin.liberarConexion(c1);

        admin.liberarConexion(c3);

        admin.liberarConexion(c5);

        admin.mostrarConexiones();
    }
}
