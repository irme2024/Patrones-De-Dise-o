package admin;

import interfaces.AdminConexion;
import model.ConexionBaseDatos;

import java.util.ArrayList;
import java.util.List;

public class AdminConexiones implements AdminConexion {

    private static AdminConexiones instancia;

    private final List<ConexionBaseDatos> conexiones;

    private static final int MAXIMO = 3;

    private AdminConexiones() {

        conexiones = new ArrayList<>();

        for(int i = 1; i <= MAXIMO; i++) {

            conexiones.add(new ConexionBaseDatos(i));
        }
    }

    public static AdminConexiones getInstancia() {

        if(instancia == null) {

            instancia = new AdminConexiones();
        }

        return instancia;
    }

    @Override
    public ConexionBaseDatos obtenerConexion() {

        for(ConexionBaseDatos conexion : this.conexiones) {

            if(conexion.estaDisponible()) {

                conexion.abrir();

                return conexion;
            }
        }

        System.out.println("No hay conexiones disponibles");

        return null;
    }

    @Override
    public void liberarConexion(ConexionBaseDatos conexion) {

        if(conexion != null) {

            conexion.cerrar();
        }
    }

    @Override
    public void mostrarConexiones() {

        System.out.println("\nESTADO DE CONEXIONES");

        for(ConexionBaseDatos conexion : this.conexiones) {

            conexion.mostrarEstado();
        }
    }
}